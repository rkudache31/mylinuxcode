#!/bin/bash

##################################################################
#Auther : Auther Name
#Implimentation Date : DD/MM/YYYY
#Version : V.0.1.2
#purpose : 
#
#
#Cahnges done : 
#changes done by :
#change date :
############################################################

echo "please enter your name"
echo
read name
echo "your name is $name"
echo "details of student"
echo "student name :"
read stname
echo "class of the student : "
read class_name
echo "percentage of the student : "
read percentage

echo

echo "student name is : $stname"
echo "Studding in class : $class_name"
echo "percentage : $percentage"
