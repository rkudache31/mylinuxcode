#!/bin/bash

# Example of relational operator


if [ $# != 2 ]
then
 echo "usage : $0 arg1 arg2"
 exit 1
fi

a=$1
b=$2

if [ $a -eq $b ]  # for not equal we can use -ne
then
   echo "both are equal"
else
   echo "both are not equal"
fi

echo
if [ $a -gt $b ]  # for not equal we can use -lt
then
   echo "a is greater then b"
else
   echo "a is not greater then b"
fi

echo

if [ $a -ge $b ]  # for not equal we can use -le
then
   echo "$a greater or equal"
else
   echo "$b greater or equal"
fi
