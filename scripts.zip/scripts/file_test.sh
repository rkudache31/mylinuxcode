#!/bin/bash

# file testing 

FILEPATH="/home/adminuser/ravi/scripts/test.txt"

if [ -e ${FILEPATH} ]
then
   echo "File is present"
else
  echo " fole is not present"
fi

if [ -r ${FILEPATH} ]
then
   echo "file is having read permission"
else
   echo "file does not have read permossion"
fi

if [ -x ${FILEPATH} ]
then
   echo "file have the execute permission"
else
   echo "file does not have the execute permission"
fi

if [ -w ${FILEPATH} ]
then
   echo "file is having write permission"
else 
   echo "file does not have the write permission"
fi

if [ -s ${FILEPATH} ]
then
   echo "file size is zero"
else 
   echo "file size is not zero"
fi


if [ -d ${FILEPATH} ]
then
   echo "Thsi is the DIR "
else 
   echo "this is file"
fi

