#!/bin/bash

option=$1

USAGE(){
   echo "usage : $0 start/stop/restart/status "
   }

STATUS()
{

 echo "status of the current process is running"
 if [[ $1 -eq 'st' ]]
 then
    echo "function is stopping"
 fi
}


START(){
echo "starting the process"
}

STOP(){
echo "stop the proces"
 STATUS st
}


RESTART(){
"restarting the process"
}

case $option in 

status)
    echo "STATUS fucntions call"
    STATUS   
    ;;
start)
    echo "FUNCTION call"
    START
  ;;
stop)
    echo "stop function call"
    STOP
  ;;
restart)
   echo "restart function call"
   RESTART
 ;;
 *)
  echo "wrong option choosed"
  USAGE

esac

