#!/bin/bash

#simple example of he fuction

function_name()
{
echo "Hi i am inside the function"

}
function_name

