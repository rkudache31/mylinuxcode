#!/bin/bash  
#Bash Until Loop example with a single condition  
  
i=1  
until [ $i -gt 10 ]  
do  
echo $i  
((i++))  
done  
