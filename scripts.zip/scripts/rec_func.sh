#!/bin/bash


i=1

rec_func(){
  echo "$i"
   ((i++))
  if [ $i -le 5 ]
  then
    rec_func 
  fi
}

rec_func

