#!/bin/bash

for a in {1..5}
do
 echo "$a"
done
