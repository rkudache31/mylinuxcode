#!/bin/bash

# recurshive example 

i=1

rec_func(){
   if [[ $i -le 5 ]]
   then
     echo "value $i"
     ((i++))
     rec_func
   fi 
}


rec_func
