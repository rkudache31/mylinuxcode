#!/bin/bash  
#Bash Until Loop example with a single condition  
  
i=1  
while [ $i -lt 10 ]  
do  
echo $i  
((i++))  
done  
