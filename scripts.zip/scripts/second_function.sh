#!/bin/bash

#defining the function 

second_function(){

echo "parameter pass to the function is $1 and $2"

}

#calling function from here 

second_function hello world 
