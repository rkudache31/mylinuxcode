#!/bin/bash

# continue statement example

arr="1 2 3 4 5 6"

for n in $arr
do
  var=`expr $n % 2`
  if [ $var -eq 0 ]
  then
     echo "Number is Even $n"
     continue
 fi
 echo "Odd number $n"
done

