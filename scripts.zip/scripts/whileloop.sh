#!/bin/bash

# while loop example

while read line
do 
echo $line |grep "nologin"
if [ $? -eq 0 ]
then
echo $line
fi
done</etc/passwd
