#!/bin/bash

#function one defination
function_one(){
   echo "Inside the function one"
   #calling function_two fron function_one
   function_two
}

#function_two defination
function_two(){
echo "inside the second function"
}

#calling function one
function_one
