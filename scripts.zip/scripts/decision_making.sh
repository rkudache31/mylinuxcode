#!/bin/bash

# If and else conditional statements 

a=$1
b=$2

if [ $a -gt $b ]
then 
   echo " Var a is greater then var b "

elif [ $a -lt $b ]
then
   echo " a is lesser"
elif [ $a == $b ]
then
   echo " both are equal"
else
   echo "nothing matched"
fi

