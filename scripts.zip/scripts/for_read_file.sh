#!/bin/bash

path="/home/adminuser/ravi/script/"

for file in $path/ *.sh
do
 echo "$file"
done
