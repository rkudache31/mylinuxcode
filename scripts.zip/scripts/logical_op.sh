#!/bin/bash

#logical operator example

a=$1
b=$2

if [ $a != $b ]
then 
   echo " condition is : true where $a is not equal to $b"
fi

if [ $a -gt 10 -a $b -lt 20 ]
then
   echo "$a is greater then 10 and $b is lesser then 20"
fi

if [ $a -gt 10 -o $b -lt 20 ]
then
  echo "$a is greater then 10 or $b is lesser then 20"
fi
