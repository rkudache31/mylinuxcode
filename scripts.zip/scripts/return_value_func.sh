#!/bin/bash

# returning the value from the function

return_value(){
 i=20
 echo " returning value to the function call"
 return $i
}

return_value
echo "$?"
