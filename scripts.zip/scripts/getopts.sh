#!/bin/bash


FILEPATH="/home/adminuser/ravi/scripts"

usage() {
  # Display the usage and exit.
  echo "Usage: ${0} [-nsr] [-f FILE] COMMAND" 
  echo "  -f file  pass the option with argument -f." 
  echo '  -n       check the status'
  echo '  -s       check the start the service' 
  echo '  -r       restart the service' 
  exit 1
}

# Make sure the script is not being executed with superuser privileges.
if [[ "${UID}" -eq 0 ]]
then
  echo 'Do not execute this script as root. Use the -s option instead.' >&2
  usage
fi



STOP(){
   echo "stopting the process." >&2
}

STATUS(){
   echo "current status of the process.."
}

START(){
   echo "starting the process." >&2
}





# Parse the options.
while getopts f:nsr OPTION
do
  case ${OPTION} in
    f) FILE="${OPTARG}"
;; 
    n) STATUS 
;;
    s) START 
;;
    r) STOP
;; 
    ?) usage 
;;
  esac
done


if [[ ! -e "$FILEPATHE/$FILE" ]]
then
  echo "Cannot open  file ${SERVER_LIST}." >&2
  exit 1
fi


